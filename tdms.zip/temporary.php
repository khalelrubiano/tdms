  <!-- LOG MODAL START-->
  <div class="modal" id="logModal">
      <div class="modal-background" id="logModalBg"></div>
      <div class="modal-card">

          <header class="modal-card-head has-background-info">
              <p class="modal-card-title has-text-white"><i class="fa-solid fa-user-group mr-3"></i>Shipment Log</p>
              <button class="delete" aria-label="close" onclick="closeLog()"></button>
          </header>

          <section class="modal-card-body">
              <ul>
                  <li>sample</li>
                  <li>sample</li>
                  <li>sample</li>
                  <li>sample</li>
                  <li>sample</li>
              </ul>
          </section>
      </div>
  </div>
  <!-- LOG MODAL END-->